
Removes all metadata from file
